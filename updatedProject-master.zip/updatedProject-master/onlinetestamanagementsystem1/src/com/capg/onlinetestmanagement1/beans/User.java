package com.capg.onlinetestmanagement1.beans;

public class User {
	
	private int userId;
	private String userName;
	private int password;
	public User(int userId, String userName, int password) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
	}
	public User()
	{
		
	}
	
	
}
