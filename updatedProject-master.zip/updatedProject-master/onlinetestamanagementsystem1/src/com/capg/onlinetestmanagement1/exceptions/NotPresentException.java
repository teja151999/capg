package com.capg.onlinetestmanagement1.exceptions;

public class NotPresentException extends Exception{
	
	

}
