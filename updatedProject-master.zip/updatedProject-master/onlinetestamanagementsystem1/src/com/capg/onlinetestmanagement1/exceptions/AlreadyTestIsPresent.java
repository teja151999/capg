package com.capg.onlinetestmanagement1.exceptions;

public class AlreadyTestIsPresent  extends Exception {
	
	 public AlreadyTestIsPresent(String string)
	 {
		 System.out.println(string);
	 }

}
